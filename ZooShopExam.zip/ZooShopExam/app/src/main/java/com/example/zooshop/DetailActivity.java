package com.example.zooshop;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Product product = (Product) getIntent().getSerializableExtra("product");
        if (product == null) {
            finish();
            return;
        }

        ImageView image = findViewById(R.id.productImage);
        TextView name = findViewById(R.id.productName);
        TextView price = findViewById(R.id.productPrice);
        TextView description = findViewById(R.id.productDescription);
        Button order = findViewById(R.id.orderButton);

        image.setImageResource(R.drawable.ic_paw);
        name.setText(product.description);
        price.setText("Цена: " + product.price + " руб.");
        description.setText(
                "Артикул: " + product.article + "\n" +
                "Производитель: " + product.manufacturer + "\n" +
                "Поставщик: " + product.supplier + "\n\n" +
                product.description
        );

        order.setOnClickListener(v ->
                Toast.makeText(DetailActivity.this, "Товар заказан", Toast.LENGTH_SHORT).show()
        );
    }
}

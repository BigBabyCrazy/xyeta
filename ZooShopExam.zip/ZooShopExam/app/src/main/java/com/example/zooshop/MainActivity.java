package com.example.zooshop;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private final ArrayList<Product> products = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView list = findViewById(R.id.productList);
        loadProducts();

        ArrayAdapter<Product> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                products
        );
        list.setAdapter(adapter);

        list.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);
            intent.putExtra("product", products.get(position));
            startActivity(intent);
        });
    }

    private void loadProducts() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(getAssets().open("products.csv"), StandardCharsets.UTF_8))) {

            String line;
            boolean header = true;
            while ((line = reader.readLine()) != null) {
                if (header) {
                    header = false;
                    continue;
                }
                String[] p = line.split(";", -1);
                if (p.length >= 6) {
                    products.add(new Product(p[0], p[1], p[2], p[3], p[4], p[5]));
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось загрузить товары", Toast.LENGTH_LONG).show();
        }
    }
}

package com.example.zooshop;

import java.io.Serializable;

public class Product implements Serializable {
    public String article;
    public String manufacturer;
    public String supplier;
    public String description;
    public String price;
    public String image;

    public Product(String article, String manufacturer, String supplier,
                   String description, String price, String image) {
        this.article = article;
        this.manufacturer = manufacturer;
        this.supplier = supplier;
        this.description = description;
        this.price = price;
        this.image = image;
    }

    @Override
    public String toString() {
        return description + " — " + price + " руб.";
    }
}
